
pub fn run() {
    println!("✅ Explorer command executed successfully!");
}
