
pub fn run() {
    println!("✅ Stake command executed successfully!");
}
