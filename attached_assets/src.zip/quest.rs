
pub fn run() {
    println!("✅ Quest command executed successfully!");
}
