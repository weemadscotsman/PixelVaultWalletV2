
pub fn run() {
    println!("✅ Mint command executed successfully!");
}
