
pub fn run() {
    println!("✅ Airdrop command executed successfully!");
}
