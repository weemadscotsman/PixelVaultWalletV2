
import express from 'express';
import walletRoutes from './routes/wallet';
import stakeRoutes from './routes/stake';
import txRoutes from './routes/tx';
import authRoutes from './routes/auth';
import thringletRoutes from './routes/thringlet';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/api/ping', (req, res) => {
    res.status(200).json({ status: "ok", time: Date.now() });
});

app.use('/api/wallet', walletRoutes);
app.use('/api/stake', stakeRoutes);
app.use('/api/tx', txRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/thringlet', thringletRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
