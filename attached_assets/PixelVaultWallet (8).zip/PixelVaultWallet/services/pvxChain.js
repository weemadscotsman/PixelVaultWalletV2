exports.getBalance = async (address) => {
  return "694200000.00 PVX";
};