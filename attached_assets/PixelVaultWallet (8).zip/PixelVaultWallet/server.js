const express = require('express');
const walletRoutes = require('./routes/wallet');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use('/api/wallet', walletRoutes);

app.listen(PORT, () => {
  console.log(`🚀 PixelVaultWallet backend running on port ${PORT}`);
});