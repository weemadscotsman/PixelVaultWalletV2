# PixelVaultWallet Backend

Simple Express backend with a balance check endpoint for PVX token.