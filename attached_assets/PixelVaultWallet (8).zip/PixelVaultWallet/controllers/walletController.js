const pvxChain = require('../services/pvxChain');

exports.getBalance = async (req, res) => {
  try {
    const { address } = req.params;
    const balance = await pvxChain.getBalance(address);
    res.json({ address, balance });
  } catch (error) {
    console.error('❌ Error getting balance:', error);
    res.status(500).json({ error: 'Failed to fetch balance' });
  }
};